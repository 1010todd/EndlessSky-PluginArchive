# MechSummoner
 Adds self-managing ally ships to Endless Sky.

 Mechsummoner is an in-universe company; they operate across a wide swathe of human space, particularly in the dirt belt and up in Megaparsec territory (northern syndicate space). Their AI fleets are designed for maximum convenience.