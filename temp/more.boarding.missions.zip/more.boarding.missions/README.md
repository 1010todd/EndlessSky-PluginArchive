### more boarding missions <br>
<br>
<br>
Adds 27 boarding and assisting missions. Boarding Free Worlds, Republic, Syndicate, Militia, Pirates, Korath or Hai can trigger them. Bigger ships give higher rewards.<br>
<br>
<ul>
<li> 7 Pirate boarding missions for credits<br>
  (by ship categories, 20% chance, 5.000 to 25.000 credits, repeatable)</li>
<li> 4 Pirate boarding missions for an android<br>
  (by ship categories, 1-4% chance, outfit "NDR-114 Android" as reward, repeatable)</li>
<li> 7 Human assisting boarding missions<br>
  (by ship categories, 20% chance, 10.000 to 30.000 credits, repeatable)</li>
<li> 7 Hai assisting boarding missions<br>
  (by ship categories, 20% chance, 20.000 to 60.000 credits, repeatable)</li>
<li> 2 Korath boarding missions<br>
  (for the bigger ship categories, 2-3% chance, outfit "Cloaking Device" as reward, repeatable)</li>
</ul>
<br>
<br>
2023-08-29<br>
added 2 korath boarding missions with a rare chance for a cloaking device<br>
added 4 pirate boarding missions with rare chance for an android<br>
added icon and reworked readme<br>
