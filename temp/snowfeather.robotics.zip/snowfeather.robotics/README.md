### snowfeather robotics <br>
<br>
<br>
Adds three missions that lead to adding androids to the outfitter on Snowfeather(Hai space). <br>
Starts on Snowfeather(Bore Fah) when having at least one android installed. <br>
<br>
To get an android, which is needed to start this plugin, do the remnant mission 'shattered light 4'. Alternatively my plugin 'more.boarding.missions' give androids as rare reward for boarding pirates.<br>
The new buyable androids are a little bit more expensive than the original ones.<br>
<br>
<br>
2023-08-29<br>
removed remnant mission requirement<br>